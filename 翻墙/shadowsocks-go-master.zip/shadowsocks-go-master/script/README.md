# About shadowsocks.exe

Copied `goagent.exe`, modified the string table and icon using reshack.

Thanks for the taskbar project created by @phuslu.

